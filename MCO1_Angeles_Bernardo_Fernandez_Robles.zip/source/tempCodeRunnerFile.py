#to run, simply run app.py or gui.py, further instructions in the docs
